# Changelog

One section per release, newest first, headed `## X.Y.Z`. Anything that breaks a consumer goes under `### Breaking`; `bun run propagate` refuses a range that holds one unless it is given `--accept-breaking`. Work in progress collects under `## Unreleased` until the release renames it.

## 0.4.0

### Added

- `InfoTip`, an info icon that shows a short text on hover or keyboard focus, for a note that would otherwise sit under a control and crowd it. The icon is named by the text, so a screen reader announces it. `InfoTipProps` types it. It carries no `'use client'`, so a React Server Component can render it.
- `Row` takes `info`, a short text shown by an `InfoTip` beside the label: a quieter alternative to `description`.

## 0.3.0

### Changed

- `Button` is shorter, so it lines up with what sits beside it. `md`, the default, is 32px tall instead of 40px: the height of an `Avatar` at its default size, and of `TextField`, `SearchField` and `Select`. `sm` is 28px instead of 32px, the height of `IconButton`, which keeps the two sizes a step apart. `ConfirmButton` is `sm` by default, so asking for confirmation no longer grows an icon-only one from 28px to 32px. Padding and type are unchanged, and `buttonClassName` returns the new heights. The shell's copy is still 32px and 40px.

## 0.2.0

### Added

- `Row` takes `stacked`, which puts its control on a line of its own under the label and description instead of beside them, for a control too wide to share the line, such as a slider or a select in a narrow column. Without it the control stays beside the label, as before.

## 0.1.0

### Added

- `scoreBySubstring(query, target, penalty?)`, the scorer for consumers without their own ranking. It ignores case, ranks an exact match above a prefix match above a substring match, subtracts the penalty, and returns -1 on a miss.
- The 22 primitives ported from the shell, each a named export: `Avatar`, `Badge`, `Button`, `Card`, `ConfirmButton`, `EmptyState`, `IconButton`, `ListRow`, `NavRow`, `PageHeader`, `PageTitle`, `PickerTile`, `Row`, `SearchField`, `SearchPicker`, `Section`, `Segmented`, `Select`, `Slider`, `Spinner`, `TextField` and `Toggle`. Thirteen carry `'use client'`; the other nine render in React Server Components.
- Their 30 prop and option types, plus `SearchScorer`, the signature of a ranking function: `(query, target, penalty?) => number`.
- `SearchPicker` ranks with a required `score` prop instead of the shell's launcher scorer. Pass `scoreBySubstring` unless you rank results yourself.
- `Slider` sets `--alpine-slider-progress` rather than the shell's `--slider-progress`, so it no longer shares a custom property with the shell's topbar sliders.
- `SCAN_BEACON_CLASS`, a class that only the library's compiled files contain. A consumer's built CSS holds `--alpine-ui-scanned` exactly when its Tailwind scanned the library.
- `@alpine/ui/index.css`, imported after `tailwindcss`. It declares `@source "../dist"`, so the consumer's Tailwind generates the classes the compiled components use, and brings three parts ported from the shell:
  - the 27 `--alpine-*` tokens derived from `--alpine-ground`, light on `:root` and dark on `data-theme="dark"`. A bare `data-theme` selector themes any subtree, and the `:root`-qualified selectors keep their specificity on `<html>`;
  - the Tailwind theme: `@theme inline` maps the tokens to utilities such as `bg-fill-solid`, `text-ink-primary` and `border-line-hairline`, next to the type, radius, spacing and easing scale (`text-dense`, `text-eyebrow`, `rounded-card`, `rounded-field`, `ease-state`) and `font-display`, which falls back to Georgia. The sans and mono stacks stay with each consumer;
  - the unlayered component rules: `.ui-slider`, filled from a registered `--alpine-slider-progress`, and `.focus-ring:focus-visible`.
- `@alpine/ui/palettes/paper.css`, the opt-in paper palette: the website's light ramp on `data-palette="paper"`, on `<html>` or on any subtree. It sets every token but `--alpine-ground`, so a paper subtree inside a dark theme keeps paper's colours. Import it after `index.css`.
- `buttonClassName({ variant, size, className })`, the classes `Button` renders, for an element that should look like a button without being one, such as a link. It carries no `'use client'`, so a React Server Component can call it. `ButtonClassNameOptions` types its argument.
- `Button` takes the native attributes of a `<button>` and a `ref`, and passes them to the element it renders, so a consumer can set `type`, `name`, `form` or `aria-haspopup`. `onClick` is optional and receives the click event. `type` still defaults to `"button"`, so a `Button` submits a form only when it is given `type="submit"`. `aria-busy` stays with the `busy` prop.
- `IconButton` takes `shape="round"` for a circle; the default, `"square"`, keeps the rounded field shape. `IconButtonShape` types it. `IconButton` also takes the native attributes of a `<button>` and a `ref`, so a menu toggle can carry `aria-expanded`, and its `onClick` receives the click event. `label` still names it, as `aria-label` and `title`.
- `EmptyState` takes `variant="dashed"` for a dashed border in the stronger line colour, the look of a box still waiting for its content. The default, `"solid"`, keeps the hairline border. `EmptyStateVariant` types it.
- `TextField` takes the input types `email`, `url`, `search` and `tel` next to `text` and `password`; `TextFieldType` types them. It also passes the native attributes of an `<input>` to its input, the form attributes included: `name`, `id`, `required`, `autoComplete`, `maxLength`, `inputMode` and `aria-describedby`, among others. `className` still lays out the wrapper, `label` still names the input, and `onChange` and `onSubmit` keep their string and Enter-key signatures.
- `Slider` reports fractional steps. It reads the value with `Number()` instead of `parseInt`, so `step={0.5}` reports 2.5 where the shell's copy reports 2. It also takes a `className` for the layout of its row.
- `Spinner` takes an optional `label`. With one it renders `role="status"` named by the label, so a spinner that stands alone is announced. Without one it stays hidden from assistive technology, as before, for a spinner that sits beside words saying the same thing.
- `Segmented` and `Select` take readonly option arrays, such as a constant declared `as const`, so a consumer no longer copies its options into a fresh array first. Mutable arrays still work.
- `.ui-slider` also styles Firefox's range parts: `::-moz-range-thumb` is hidden like the WebKit thumb, and `::-moz-range-track` and `::-moz-range-progress` are transparent, so the fill drawn from `--alpine-slider-progress` shows in Firefox as it does in Chromium. The shell's copy styles only the WebKit thumb.
