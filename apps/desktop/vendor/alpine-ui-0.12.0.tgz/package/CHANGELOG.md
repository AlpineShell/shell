# Changelog

One section per release, newest first, headed `## X.Y.Z`. Anything that breaks a consumer goes under `### Breaking`; `bun run propagate` refuses a range that holds one unless it is given `--accept-breaking`. Work in progress collects under `## Unreleased` until the release renames it.

## 0.12.0

### Changed

- `Dialog` and `AlertDialog` sit flat: no border and no shadow, the field radius instead of the card radius, and a lighter backdrop (`--alpine-scrim` is 14% black on light grounds, also on the paper palette, and 40% on dark). They close at once instead of fading out; opening still fades in.
- The `Dialog` close button is a plain cross in the corner, as far from the top as from the right, with no box on hover: its stroke grows thicker instead, and it no longer animates.
- `SearchField` shows a still search icon instead of the animated one.

## 0.11.0

### Breaking

- `IconButton` shows its `label` in a `Tooltip` by default and no longer sets the native `title`, so a test that finds an icon button by its title must find it by its accessible name instead. `tooltip` still places the tooltip (`top`, the default, `topStart`, `topEnd`, `bottom`, `bottomStart` or `bottomEnd`), now as a popup against the window instead of a bubble inside the button, and `tooltip={false}` turns it off. An `IconButton` wrapped in a `Tooltip` of its own shows only that one.

### Added

- Animated icons: `PlusIcon`, `XIcon`, `CheckIcon`, `CopyIcon`, `TrashIcon`, `SettingsIcon`, `RefreshCwIcon`, `RotateCcwIcon`, `ChevronDownIcon`, `ChevronRightIcon`, `ChevronUpIcon`, `ExternalLinkIcon`, `ArrowUpRightIcon`, `ArrowLeftIcon`, `ArrowRightIcon`, `SearchIcon`, `MenuIcon`, `TriangleAlertIcon`, `DownloadIcon`, `LogOutIcon`, `WifiIcon`, `BluetoothIcon`, `MoonIcon`, `SunIcon`, `KeyboardIcon`, `LinkIcon`, `LockIcon`, `BellIcon` and `PuzzleIcon`. They draw the Lucide glyphs the two products use, at 16px by default, and play a short animation adapted from lucide-animated (MIT, see `THIRD_PARTY_NOTICES.md`) while the control around them is hovered, focused from the keyboard or pressed: `Button`, `IconButton`, `ConfirmButton`, `Menu` items, `Tabs`, `NavRow`, `ListRow`, `PickerTile`, `Select` and `SearchField` play them without any wiring. `active` plays one on its own, `label` names it for assistive tech, and a plain lucide-react icon keeps working unanimated. They stay still when reduced motion is asked for. `AnimatedIconProps` types them.
- `motion` 14 is a dependency, for the animated icons.
- `Button` takes `trailingIcon`, set after the label in a slot of its own. `buttonClassName` takes `iconSide` (`start`, `end` or `both`, typed by `ButtonIconSide`) so a link styled as a button pads around its icons the same way.
- `@base-ui/react` 1.9 is a dependency. The behaviour-heavy primitives below are built on it, so focus management, Escape, scroll lock and keyboard navigation come from one place.
- `Dialog`: a modal with a `title`, an optional `description`, a body, an `actions` slot (a node, or a function given `close`) and a close button. `size` is `sm`, `md` or `lg`. It works controlled (`open`, `onOpenChange`), uncontrolled (`defaultOpen`) and with or without a `trigger`; `dismissible={false}` keeps it open on Escape and backdrop presses while something is in flight. Focus moves to its first field and back to whatever opened it; the page under it does not scroll; its fade and scale run only without reduced motion. `DialogProps`, `DialogSize` and `DialogActions` type it.
- `AlertDialog`: a confirmation with a `title`, an optional `description`, a cancel button and a confirm button in the `primary` or `danger` `variant`. When `onConfirm` returns a promise, it stays open and busy until the promise settles and closes only when it resolves. `AlertDialogProps` and `AlertDialogVariant` type it.
- `Menu`: a dropdown opened by its `trigger`, listing `items` as actions with an optional icon and shortcut, danger actions, links (with `current` for the page you are on), checkbox items, radio groups, group labels and separators, with arrow keys and typeahead. `renderLink` renders its links through a router link. `MenuProps`, `MenuEntry`, `MenuAction`, `MenuLink`, `MenuCheckbox`, `MenuRadioGroup`, `MenuRadioOption`, `MenuSeparator` and `MenuGroup` type it.
- `Tabs`: underlined tabs that switch panels, controlled or uncontrolled, with an optional count per tab. `TabsProps` and `TabsItem` type it.
- `TabNav`: the same underlined look for tabs that are navigation, rendered as links in a `nav` with `aria-current` on the current one rather than as a tablist. It is server-safe, and `renderLink` renders a router link. `TabNavProps`, `TabNavItem` and `LinkRenderer` type it.
- `Tooltip`: a hint shown on hover and focus, placed by `side` and `align`, after `delay` milliseconds. `TooltipProps`, `PopupSide` and `PopupAlign` type it.
- `Table`, `TableHead`, `TableRow` and `TableCell`, all server-safe: a dense table on hairlines named by its `label`, with an optional sticky head on the `backdrop` it sits on (offset by `--alpine-table-sticky-top`), `numeric` columns aligned right with even figures, and `TableRow variant="clickable"` and `muted`. The cells and rows pass native attributes through. `TableProps`, `TableBackdrop`, `TableHeadProps`, `TableRowProps`, `TableRowVariant` and `TableCellProps` type them.
- `StatusDot`, server-safe: a status as a coloured dot and a word, in the `neutral`, `info`, `success`, `warning`, `danger` or `progress` tone; `progress` pulses unless reduced motion is asked for. `StatusDotProps` and `StatusDotTone` type it.
- `TextArea`: the multi-line `TextField`, with a `label`, `invalid` and the native attributes of a textarea, a `ref` included. Its description and error come only from a surrounding `Field`. `TextAreaProps` types it.
- `Field`: a visible label, an optional description and an optional error around a `TextField`, `TextArea` or `Select`, wired to the control with `id`, `aria-labelledby`, `aria-describedby` and `aria-invalid`. The control inside it needs no `label` of its own, and a `Select` inside it fills the width. An `error` sits in a warning-tinted strip with a warning icon, attached to the top of the control as one shape, and draws the control's border in the warning tone; it fades in unless reduced motion is asked for. The description stays below the control. `FieldProps` types it.
- `Dialog` and `AlertDialog` take `titleVariant`: `sans`, the default, or `display` for the title in the display serif. `DialogTitleVariant` types it.
- Tokens: `--alpine-info` (`bg-info`, `text-info`) for the informational tone, `--alpine-shadow-modal` (`shadow-modal`) for dialogs, and `--alpine-warning-surface` (`bg-warning-surface`) and `--alpine-warning-line` (`border-warning-line`) for warning-tinted surfaces, in the light and dark themes and the paper palette.

### Changed

- `Button`, `ConfirmButton` and `buttonClassName` default to the `square` shape: the field corners and a medium weight. Pass `shape="round"` for the pill.
- The outline `Segmented` takes the field corners instead of a pill.
- The light theme's `--alpine-ground` is `#f7f7f7` instead of `#d6d6d6`, so light surfaces read as white. Every light shade derives from it.
- `InfoTip` draws its text with `Tooltip`, in a popup placed against the window rather than inside its row, so a clipping container no longer cuts it off. Its props are unchanged and it stays server-safe.
- `IconButton`'s `onClick` is optional, so it can be the trigger of a `Menu`, `Dialog` or `Tooltip`.
- `TextField` sets `aria-invalid` when it is `invalid`.
- `TextField` and `Select` take their `label` as optional, so they can sit inside a `Field` without one. Outside a `Field`, one without a `label` (or `aria-labelledby` on a `TextField`) logs an error in development. Existing code is unaffected.
- A `Button` with an icon pads the icon side less than the label side (12 and 16px at md, 10 and 12px at sm), so the label sits optically centred. Its icons sit in fixed 16px (md) or 14px (sm) slots, 8 or 6px from the label. While `busy`, the spinner takes the icon's slot, or lies over the label when there is no icon, so the button never changes width; a busy button no longer dims.
- Pressed controls give feedback: buttons, icon buttons and picker tiles shrink slightly unless reduced motion is asked for, and rows, menu items, list options and segments darken. An outline `Button` and an outline `NavRow` darken their border on hover.
- Disabled controls dim to half strength, the `Toggle` and a disabled `ListRow` included; a disabled `Row` dims once even when its control is disabled too.
- Small controls reach at least a 32px hit area without changing their size: the sm `Button`, `IconButton`, `Toggle`, `Segmented` options, the `SearchField` clear button and `InfoTip`.
- The outline `Segmented` stands 32px tall, as tall as an outline `Select` and a md `Button` beside it, and moves its choice with the arrow keys from a single tab stop.
- The `Select` trigger pads its text like a `TextField`, and its options line up with it; its chevron turns while the list is open, the list scales in, it takes typeahead across several letters, and a cut-off label carries a title. `TextField`, `TextArea` and `SearchField` darken their border on hover and show a soft focus halo, and a `TextField` with an icon pads that side less.
- The card `NavRow` pads like a card `ListRow` (at least 56px tall, 12px in, the icon in a 28px column), so the two line up in one list.
- The `Field` error strip lines its sign and text up with the icon and text of the control under it, and slides open instead of pushing the page down at once.
- The `Dialog` close button sits on the title line, with the cross lined up with the edge of the content. `Dialog`, `AlertDialog`, `Menu` and `Tooltip` close a little faster than they open.
- The `Toggle` knob slides with a transform, and a long `ListRow` title or detail, `Menu` label, `SearchPicker` option or `Ticket` title carries a title so it can still be read when cut off. A clickable `TableRow` shows the focus ring when it takes focus.

## 0.10.0

### Added

- `Card` takes `variant="group"`: the rows inside it sit on a soft fill, each padded the same and at least 48px tall, with a hairline between them and the card's rounded corners on the first and last row. It holds a list of settings rows as one object, so a page reads as a few groups rather than a column of loose rows. `CardVariant` gains `group`.
- `Card` takes `variant="list"`: the same soft fill and hairlines between rows, without padding the rows, for rows that pad themselves such as `ListRow variant="plain"`.
- `Section` takes `variant="label"`: the title as a small quiet label with a tighter gap below it, for a group card whose rows already say what they are. `SectionVariant` types it, and `heading`, the bold title, stays the default.
- `PageTitle` takes `variant="plain"`: the title in the sans face at a medium weight instead of the display serif, for a settings window set in the same type as the shell around it. `PageTitleVariant` types it, and `display` stays the default. `PageHeader` takes the same `variant` and passes it to its title.
- `NavRow` takes `variant="flat"`: the row without its own card, filling the width with a soft fill on hover, for a link inside a group card. `NavRowVariant` types it, and `card` stays the default.
- `NavRow` takes `detail`: a short quiet value before the chevron, such as the network a Wi-Fi row is connected to.
- `Toggle` takes `variant="compact"`: a 32 by 18 switch with a flat knob, the knob in the secondary ink while off and the on-solid colour while on, sized for the rows of a group card. `ToggleVariant` types it, and `pill`, the 38 by 22 switch, stays the default.
- `Segmented` takes `variant="filled"`: the options on a soft rounded fill instead of an outlined pill, 24px tall in the small text, with the chosen one in the solid fill. `SegmentedVariant` types it, and `outline` stays the default.
- `Select` takes `variant="filled"`: a 28px trigger on a soft fill without a border, matching the filled `Segmented`. `SelectVariant` types it, and `outline` stays the default.
- `Slider` takes `variant="wide"`: a 256px track instead of 176px, for a row with room to spare. `SliderVariant` types it, and `regular` stays the default.
- `Button` takes `shape="square"`: the field's rounded corners and a medium weight instead of a pill, for the buttons of a settings page. `ConfirmButton` takes the same `shape` and gives it to its trigger, Cancel and confirm buttons, and `buttonClassName` takes it too. `ButtonShape` types it, and `round` stays the default.
- `Button` takes `variant="soft"`, a light tint of the ink without a border, and `variant="dangerSoft"`, the same tint with the label in the danger colour, for the everyday and the destructive action in a row.
- `.focus-ring-inset` draws the focus ring 2px inside the element instead of 2px outside, for a control that fills a container that clips its corners.

### Changed

- `ListRow variant="plain"` fills the row edge to edge, without rounded corners, and lights it on hover only when it has `onActivate` and is not disabled, so a row that does nothing on click no longer looks clickable. Its padding matches a `Card variant="group"` row, and its activate button draws the focus ring inside the row.
- `Card variant="list"` no longer pads its rows by 4px, so plain rows reach its edges.

## 0.9.1

### Fixed

- `Ticket`: a stub with no stamps no longer holds an empty stamp column, so a lone `action`, like the `+` on a blank ticket, sits in the middle of the stub instead of half a gap below it.

## 0.9.0

### Added

- `Ticket`: a licence or pass drawn as a ticket. The left part holds the title, set in the display font, with an optional serial beside it in a quieter ink, a one-line detail and anything passed as children. A dashed tear line with a notch cut into the top and bottom edge separates it from the stub, which holds one tilted stamp per entry in `stamps` and an optional `action`. `backdrop` fills the notches with the surface the ticket sits on, `surface-0` by default or `surface-1`, `muted` quietens the title, `size="compact"` sets a smaller title and a narrower stub for a narrow window, and `variant="blank"` draws an empty ticket with a dashed outline and a quiet title, for a slot that invites a new one. `TicketProps`, `TicketStamp`, `TicketStampTone`, `TicketBackdrop`, `TicketSize` and `TicketVariant` type it. It is server-safe.

## 0.8.0

### Added

- `IconButton` takes `tooltip`: it draws its label in the library's own tooltip, the bubble `InfoTip` shows, instead of the browser's native one. The value puts the bubble above or below the button, centred on it or lined up with its start or end edge, so a button in the corner of a window keeps its tooltip inside the window. `IconButtonTooltip` types it. Without `tooltip`, the label stays the native tooltip.
- `Card` takes `variant="borderless"`: the same raised surface and rounded corners without the hairline border, for a card that should sit on the page as a soft panel rather than a framed box. `CardVariant` types it, and `solid`, the bordered card, stays the default.

## 0.7.0

### Added

- `EmptyState` takes `variant="plain"`: the title, detail and action without a frame, left-aligned, with the icon beside the title rather than above it, for a list that is simply empty and needs no box drawn around the fact.
- `ListRow` takes `variant="plain"`: the row without its card, rounded, with a soft fill on hover, for a long list such as installed apps where a card around every row turns the page into a stack of boxes. `ListRowVariant` types it.
- `ListRow` takes `revealActions`: its actions stay hidden until the row is hovered or holds focus, so a long list shows names rather than a column of buttons.

### Changed

- `Select` draws its own dropdown instead of the operating system's. The trigger keeps the height, radius, border and background it had, shows the chosen option's label with a chevron, and stays as wide as its longest option. It opens a floating list under it, or above it when there is no room below, with rounded options, the highlighted one filled and the chosen one checked. The list closes when an option is picked, when you click elsewhere, press Escape or move focus away. It follows the WAI-ARIA select-only combobox pattern: the arrow keys, Home and End move through the options, Enter or Space picks one, and a typed letter jumps to the next option starting with it. Its props are unchanged, and `label` still names it.

## 0.6.0

### Added

- `SearchPickerOption` takes `icon`, shown before the option's label.

### Changed

- `SearchPicker` draws its list without a border or background of its own, so the list sits on whatever holds it, and its empty message is plain text. Its options have rounded corners, so the highlighted one still looks finished without the frame.

## 0.5.0

### Added

- `ConfirmButton` takes `confirmOnly`: while it asks, it shows the confirm button alone, without Cancel.

### Changed

- A `ConfirmButton` that is asking now backs out when you click anywhere else, press Escape or move focus away, so it never waits on an answer nobody is giving. Asking moves focus to the confirm button, and Escape hands it back to the trigger.

## 0.4.0

### Added

- `InfoTip`, an info icon that shows a short text on hover or keyboard focus, for a note that would otherwise sit under a control and crowd it. The icon is named by the text, so a screen reader announces it. `InfoTipProps` types it. It carries no `'use client'`, so a React Server Component can render it.
- `Row` takes `info`, a short text shown by an `InfoTip` beside the label: a quieter alternative to `description`.

## 0.3.0

### Changed

- `Button` is shorter, so it lines up with what sits beside it. `md`, the default, is 32px tall instead of 40px: the height of an `Avatar` at its default size, and of `TextField`, `SearchField` and `Select`. `sm` is 28px instead of 32px, the height of `IconButton`, which keeps the two sizes a step apart. `ConfirmButton` is `sm` by default, so asking for confirmation no longer grows an icon-only one from 28px to 32px. Padding and type are unchanged, and `buttonClassName` returns the new heights. The shell's copy is still 32px and 40px.

## 0.2.0

### Added

- `Row` takes `stacked`, which puts its control on a line of its own under the label and description instead of beside them, for a control too wide to share the line, such as a slider or a select in a narrow column. Without it the control stays beside the label, as before.

## 0.1.0

### Added

- `scoreBySubstring(query, target, penalty?)`, the scorer for consumers without their own ranking. It ignores case, ranks an exact match above a prefix match above a substring match, subtracts the penalty, and returns -1 on a miss.
- The 22 primitives ported from the shell, each a named export: `Avatar`, `Badge`, `Button`, `Card`, `ConfirmButton`, `EmptyState`, `IconButton`, `ListRow`, `NavRow`, `PageHeader`, `PageTitle`, `PickerTile`, `Row`, `SearchField`, `SearchPicker`, `Section`, `Segmented`, `Select`, `Slider`, `Spinner`, `TextField` and `Toggle`. Thirteen carry `'use client'`; the other nine render in React Server Components.
- Their 30 prop and option types, plus `SearchScorer`, the signature of a ranking function: `(query, target, penalty?) => number`.
- `SearchPicker` ranks with a required `score` prop instead of the shell's launcher scorer. Pass `scoreBySubstring` unless you rank results yourself.
- `Slider` sets `--alpine-slider-progress` rather than the shell's `--slider-progress`, so it no longer shares a custom property with the shell's topbar sliders.
- `SCAN_BEACON_CLASS`, a class that only the library's compiled files contain. A consumer's built CSS holds `--alpine-ui-scanned` exactly when its Tailwind scanned the library.
- `@alpine/ui/index.css`, imported after `tailwindcss`. It declares `@source "../dist"`, so the consumer's Tailwind generates the classes the compiled components use, and brings three parts ported from the shell:
  - the 27 `--alpine-*` tokens derived from `--alpine-ground`, light on `:root` and dark on `data-theme="dark"`. A bare `data-theme` selector themes any subtree, and the `:root`-qualified selectors keep their specificity on `<html>`;
  - the Tailwind theme: `@theme inline` maps the tokens to utilities such as `bg-fill-solid`, `text-ink-primary` and `border-line-hairline`, next to the type, radius, spacing and easing scale (`text-dense`, `text-eyebrow`, `rounded-card`, `rounded-field`, `ease-state`) and `font-display`, which falls back to Georgia. The sans and mono stacks stay with each consumer;
  - the unlayered component rules: `.ui-slider`, filled from a registered `--alpine-slider-progress`, and `.focus-ring:focus-visible`.
- `@alpine/ui/palettes/paper.css`, the opt-in paper palette: the website's light ramp on `data-palette="paper"`, on `<html>` or on any subtree. It sets every token but `--alpine-ground`, so a paper subtree inside a dark theme keeps paper's colours. Import it after `index.css`.
- `buttonClassName({ variant, size, className })`, the classes `Button` renders, for an element that should look like a button without being one, such as a link. It carries no `'use client'`, so a React Server Component can call it. `ButtonClassNameOptions` types its argument.
- `Button` takes the native attributes of a `<button>` and a `ref`, and passes them to the element it renders, so a consumer can set `type`, `name`, `form` or `aria-haspopup`. `onClick` is optional and receives the click event. `type` still defaults to `"button"`, so a `Button` submits a form only when it is given `type="submit"`. `aria-busy` stays with the `busy` prop.
- `IconButton` takes `shape="round"` for a circle; the default, `"square"`, keeps the rounded field shape. `IconButtonShape` types it. `IconButton` also takes the native attributes of a `<button>` and a `ref`, so a menu toggle can carry `aria-expanded`, and its `onClick` receives the click event. `label` still names it, as `aria-label` and `title`.
- `EmptyState` takes `variant="dashed"` for a dashed border in the stronger line colour, the look of a box still waiting for its content. The default, `"solid"`, keeps the hairline border. `EmptyStateVariant` types it.
- `TextField` takes the input types `email`, `url`, `search` and `tel` next to `text` and `password`; `TextFieldType` types them. It also passes the native attributes of an `<input>` to its input, the form attributes included: `name`, `id`, `required`, `autoComplete`, `maxLength`, `inputMode` and `aria-describedby`, among others. `className` still lays out the wrapper, `label` still names the input, and `onChange` and `onSubmit` keep their string and Enter-key signatures.
- `Slider` reports fractional steps. It reads the value with `Number()` instead of `parseInt`, so `step={0.5}` reports 2.5 where the shell's copy reports 2. It also takes a `className` for the layout of its row.
- `Spinner` takes an optional `label`. With one it renders `role="status"` named by the label, so a spinner that stands alone is announced. Without one it stays hidden from assistive technology, as before, for a spinner that sits beside words saying the same thing.
- `Segmented` and `Select` take readonly option arrays, such as a constant declared `as const`, so a consumer no longer copies its options into a fresh array first. Mutable arrays still work.
- `.ui-slider` also styles Firefox's range parts: `::-moz-range-thumb` is hidden like the WebKit thumb, and `::-moz-range-track` and `::-moz-range-progress` are transparent, so the fill drawn from `--alpine-slider-progress` shows in Firefox as it does in Chromium. The shell's copy styles only the WebKit thumb.
