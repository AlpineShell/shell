# @alpine/ui

Shared React components and design tokens for Alpine Shell and its website.

## Installing

There is no registry. Each GitHub release carries `alpine-ui-X.Y.Z.tgz`. A consumer commits it under `vendor/` and depends on it through `file:`:

```json
{
  "dependencies": {
    "@alpine/ui": "file:vendor/alpine-ui-X.Y.Z.tgz"
  }
}
```

A consumer vendors its first release by hand. After that, `bun run propagate` moves it to each new release (see below). React 19 and React DOM 19 are peer dependencies; lucide-react comes with the package.

## Styles

The package ships CSS source for the consumer's Tailwind 4 to compile. In the stylesheet that imports Tailwind:

```css
@import "tailwindcss";
@import "@alpine/ui/index.css";
@import "@alpine/ui/palettes/paper.css";
@source not "../vendor";
```

- Import `index.css` before `palettes/paper.css`. The paper palette is optional.
- `index.css` declares `@source "../dist"`, so your Tailwind generates the classes the compiled components use.
- `@source not` keeps Tailwind out of the vendored tarball folder. Point it at `vendor/` relative to the stylesheet.
- `data-theme="dark"` switches to the dark theme and `data-palette="paper"` to the paper palette, on `<html>` or on any subtree.
- The library brings no fonts, reset, scrollbars or `color-scheme`.
- `font-display` names Averia Serif Libre and falls back to Georgia. Load the face yourself, or set `--font-display` in your own `@theme` after the import. `font-sans` and `font-mono` come from your theme.

## Using

```tsx
import { Button, SearchPicker, scoreBySubstring } from '@alpine/ui'
```

Thirteen interactive components carry `'use client'`; the rest render in React Server Components. `SearchPicker` requires a `score` function. Pass `scoreBySubstring` unless you rank results yourself.

`buttonClassName({ variant, size, className })` returns the classes `Button` renders, so a link can look like a button without being one. It carries no directive, so a Server Component can call it too:

```tsx
<a href="/pricing" className={buttonClassName({ variant: 'outline' })}>
  See pricing
</a>
```

`Button`, `IconButton` and `TextField` pass the native attributes of the element they render through, a `ref` included, so `type="submit"`, `aria-expanded`, `name` or `autoComplete` reach the DOM. `className` only lays a component out; its look comes from props such as `variant`, `size` and `shape`.

`IconButton` shows its `label` as the browser's native tooltip. Give it `tooltip` and it draws the label in the library's own tooltip instead, the bubble `InfoTip` uses, placed by the value: `top`, `topStart`, `topEnd`, `bottom`, `bottomStart` or `bottomEnd`. Near the edge of a window, pick a `Start` or `End` placement so the bubble stays inside it:

```tsx
<IconButton label="Test out, resets on restart" shape="round" tooltip="topEnd" onClick={testOut}>
  <FlaskConical size={16} />
</IconButton>
```

## Developing

Use the Bun version pinned in `package.json`.

```sh
bun install
bun run check:rules
bun run lint
bun run typecheck
bun run test
bun run build
bun run check:dist
bun run smoke
bun run playground
```

`bun run check:dist` checks the built `dist/` and the tarball `bun pm pack` makes of it: the 13 client directives, the scan beacon, and a pack that holds nothing but `package.json`, `README.md`, `CHANGELOG.md`, `dist/` and `css/`. `bun run smoke` installs that tarball into two fixtures that mirror the consumers, a Bun workspace with Vite like the shell and a Next 16 app like the website, builds both and checks what they built. It downloads the fixtures' dependencies.

`bun run playground` serves the gallery at http://127.0.0.1:5174. It renders every primitive in four panels: light, dark, a ground tinted from a top bar colour the way the shell tints its windows, and the paper palette. It compiles `src/` directly, so there is nothing to build first, and it loads local copies of the shell's fonts. `bun run playground:build` builds it into `playground/dist`, as CI does.

To try a local change in a consumer checkout before releasing:

```sh
bun run try ../website
bun run try ../alpine-shell -- bun x vite build
```

`try` builds and packs the library into `.try/` and installs it into the consumer. Without a command it waits for Enter; with a command after `--` it runs that command in the consumer's package folder. Either way it then restores the consumer's `package.json` and `bun.lock` and reinstalls. It refuses a dirty consumer tree. Paths are relative to this repo's root, where `bun run` runs scripts.

To compare two builds of a consumer's CSS, for example the shell's `dist/assets` before and after a trial:

```sh
bun run css:parity ../before-assets ../after-assets
```

It prints the added, removed and changed rules and exits 1 when the two differ. It exits 2 without comparing when a path is missing or holds no CSS rules, so a build that never ran cannot pass as parity.

## Releasing and propagating

1. Bump the minor version in `package.json` and rename `## Unreleased` in `CHANGELOG.md` to it.
2. Merge into main. `release.yml` verifies the commit, installs the packed tarball into the workspace fixture on Windows with the shell release's Bun, and publishes `vX.Y.Z` with that tarball, its SHA-256 and the CHANGELOG section. A push whose version already has a tag releases nothing.
3. Open the bump pull requests in the consumers that vendor an earlier release. propagate refuses a consumer that does not depend on the library yet, so until the shell adopts it, add `--only website`:

```sh
GH="/path/to/gh" bun run propagate vX.Y.Z
```

Add `--only shell` or `--only website` for one consumer, `--dry-run` to verify without pushing or opening pull requests, and `--accept-breaking` when the range holds a `### Breaking` entry. `GH` defaults to `gh` on the `PATH`. A dry run prints each commit's files and the pull request it would open.

## Shell sync base

The primitives, prop types, tokens and component CSS match AlpineShell/shell at commit `5608411` (`apps/desktop/src/components/ui`, `apps/desktop/src/types/shell.d.ts` and `apps/desktop/src/index.css`). They were ported at `0411738`; the shell's changes to those paths up to `5608411` touch none of the ported code. A re-sync diffs the shell from this commit and records the new one here. `Row`'s `stacked` prop came later, from the shell's `314454a`. That commit also gave the shell's `IconButton` `expanded` and `controls` props, which were not ported: the library's `IconButton` passes `aria-expanded` and `aria-controls` through as native attributes.
