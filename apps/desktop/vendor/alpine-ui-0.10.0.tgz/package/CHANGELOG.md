# Changelog

One section per release, newest first, headed `## X.Y.Z`. Anything that breaks a consumer goes under `### Breaking`; `bun run propagate` refuses a range that holds one unless it is given `--accept-breaking`. Work in progress collects under `## Unreleased` until the release renames it.

## 0.10.0

### Added

- `Card` takes `variant="group"`: the rows inside it sit on a soft fill, each padded the same and at least 48px tall, with a hairline between them and the card's rounded corners on the first and last row. It holds a list of settings rows as one object, so a page reads as a few groups rather than a column of loose rows. `CardVariant` gains `group`.
- `Card` takes `variant="list"`: the same soft fill and hairlines between rows, without padding the rows, for rows that pad themselves such as `ListRow variant="plain"`.
- `Section` takes `variant="label"`: the title as a small quiet label with a tighter gap below it, for a group card whose rows already say what they are. `SectionVariant` types it, and `heading`, the bold title, stays the default.
- `PageTitle` takes `variant="plain"`: the title in the sans face at a medium weight instead of the display serif, for a settings window set in the same type as the shell around it. `PageTitleVariant` types it, and `display` stays the default. `PageHeader` takes the same `variant` and passes it to its title.
- `NavRow` takes `variant="flat"`: the row without its own card, filling the width with a soft fill on hover, for a link inside a group card. `NavRowVariant` types it, and `card` stays the default.
- `NavRow` takes `detail`: a short quiet value before the chevron, such as the network a Wi-Fi row is connected to.
- `Toggle` takes `variant="compact"`: a 32 by 18 switch with a flat knob, the knob in the secondary ink while off and the on-solid colour while on, sized for the rows of a group card. `ToggleVariant` types it, and `pill`, the 38 by 22 switch, stays the default.
- `Segmented` takes `variant="filled"`: the options on a soft rounded fill instead of an outlined pill, 24px tall in the small text, with the chosen one in the solid fill. `SegmentedVariant` types it, and `outline` stays the default.
- `Select` takes `variant="filled"`: a 28px trigger on a soft fill without a border, matching the filled `Segmented`. `SelectVariant` types it, and `outline` stays the default.
- `Slider` takes `variant="wide"`: a 256px track instead of 176px, for a row with room to spare. `SliderVariant` types it, and `regular` stays the default.
- `Button` takes `shape="square"`: the field's rounded corners and a medium weight instead of a pill, for the buttons of a settings page. `ConfirmButton` takes the same `shape` and gives it to its trigger, Cancel and confirm buttons, and `buttonClassName` takes it too. `ButtonShape` types it, and `round` stays the default.
- `Button` takes `variant="soft"`, a light tint of the ink without a border, and `variant="dangerSoft"`, the same tint with the label in the danger colour, for the everyday and the destructive action in a row.
- `.focus-ring-inset` draws the focus ring 2px inside the element instead of 2px outside, for a control that fills a container that clips its corners.

### Changed

- `ListRow variant="plain"` fills the row edge to edge, without rounded corners, and lights it on hover only when it has `onActivate` and is not disabled, so a row that does nothing on click no longer looks clickable. Its padding matches a `Card variant="group"` row, and its activate button draws the focus ring inside the row.
- `Card variant="list"` no longer pads its rows by 4px, so plain rows reach its edges.

## 0.9.1

### Fixed

- `Ticket`: a stub with no stamps no longer holds an empty stamp column, so a lone `action`, like the `+` on a blank ticket, sits in the middle of the stub instead of half a gap below it.

## 0.9.0

### Added

- `Ticket`: a licence or pass drawn as a ticket. The left part holds the title, set in the display font, with an optional serial beside it in a quieter ink, a one-line detail and anything passed as children. A dashed tear line with a notch cut into the top and bottom edge separates it from the stub, which holds one tilted stamp per entry in `stamps` and an optional `action`. `backdrop` fills the notches with the surface the ticket sits on, `surface-0` by default or `surface-1`, `muted` quietens the title, `size="compact"` sets a smaller title and a narrower stub for a narrow window, and `variant="blank"` draws an empty ticket with a dashed outline and a quiet title, for a slot that invites a new one. `TicketProps`, `TicketStamp`, `TicketStampTone`, `TicketBackdrop`, `TicketSize` and `TicketVariant` type it. It is server-safe.

## 0.8.0

### Added

- `IconButton` takes `tooltip`: it draws its label in the library's own tooltip, the bubble `InfoTip` shows, instead of the browser's native one. The value puts the bubble above or below the button, centred on it or lined up with its start or end edge, so a button in the corner of a window keeps its tooltip inside the window. `IconButtonTooltip` types it. Without `tooltip`, the label stays the native tooltip.
- `Card` takes `variant="borderless"`: the same raised surface and rounded corners without the hairline border, for a card that should sit on the page as a soft panel rather than a framed box. `CardVariant` types it, and `solid`, the bordered card, stays the default.

## 0.7.0

### Added

- `EmptyState` takes `variant="plain"`: the title, detail and action without a frame, left-aligned, with the icon beside the title rather than above it, for a list that is simply empty and needs no box drawn around the fact.
- `ListRow` takes `variant="plain"`: the row without its card, rounded, with a soft fill on hover, for a long list such as installed apps where a card around every row turns the page into a stack of boxes. `ListRowVariant` types it.
- `ListRow` takes `revealActions`: its actions stay hidden until the row is hovered or holds focus, so a long list shows names rather than a column of buttons.

### Changed

- `Select` draws its own dropdown instead of the operating system's. The trigger keeps the height, radius, border and background it had, shows the chosen option's label with a chevron, and stays as wide as its longest option. It opens a floating list under it, or above it when there is no room below, with rounded options, the highlighted one filled and the chosen one checked. The list closes when an option is picked, when you click elsewhere, press Escape or move focus away. It follows the WAI-ARIA select-only combobox pattern: the arrow keys, Home and End move through the options, Enter or Space picks one, and a typed letter jumps to the next option starting with it. Its props are unchanged, and `label` still names it.

## 0.6.0

### Added

- `SearchPickerOption` takes `icon`, shown before the option's label.

### Changed

- `SearchPicker` draws its list without a border or background of its own, so the list sits on whatever holds it, and its empty message is plain text. Its options have rounded corners, so the highlighted one still looks finished without the frame.

## 0.5.0

### Added

- `ConfirmButton` takes `confirmOnly`: while it asks, it shows the confirm button alone, without Cancel.

### Changed

- A `ConfirmButton` that is asking now backs out when you click anywhere else, press Escape or move focus away, so it never waits on an answer nobody is giving. Asking moves focus to the confirm button, and Escape hands it back to the trigger.

## 0.4.0

### Added

- `InfoTip`, an info icon that shows a short text on hover or keyboard focus, for a note that would otherwise sit under a control and crowd it. The icon is named by the text, so a screen reader announces it. `InfoTipProps` types it. It carries no `'use client'`, so a React Server Component can render it.
- `Row` takes `info`, a short text shown by an `InfoTip` beside the label: a quieter alternative to `description`.

## 0.3.0

### Changed

- `Button` is shorter, so it lines up with what sits beside it. `md`, the default, is 32px tall instead of 40px: the height of an `Avatar` at its default size, and of `TextField`, `SearchField` and `Select`. `sm` is 28px instead of 32px, the height of `IconButton`, which keeps the two sizes a step apart. `ConfirmButton` is `sm` by default, so asking for confirmation no longer grows an icon-only one from 28px to 32px. Padding and type are unchanged, and `buttonClassName` returns the new heights. The shell's copy is still 32px and 40px.

## 0.2.0

### Added

- `Row` takes `stacked`, which puts its control on a line of its own under the label and description instead of beside them, for a control too wide to share the line, such as a slider or a select in a narrow column. Without it the control stays beside the label, as before.

## 0.1.0

### Added

- `scoreBySubstring(query, target, penalty?)`, the scorer for consumers without their own ranking. It ignores case, ranks an exact match above a prefix match above a substring match, subtracts the penalty, and returns -1 on a miss.
- The 22 primitives ported from the shell, each a named export: `Avatar`, `Badge`, `Button`, `Card`, `ConfirmButton`, `EmptyState`, `IconButton`, `ListRow`, `NavRow`, `PageHeader`, `PageTitle`, `PickerTile`, `Row`, `SearchField`, `SearchPicker`, `Section`, `Segmented`, `Select`, `Slider`, `Spinner`, `TextField` and `Toggle`. Thirteen carry `'use client'`; the other nine render in React Server Components.
- Their 30 prop and option types, plus `SearchScorer`, the signature of a ranking function: `(query, target, penalty?) => number`.
- `SearchPicker` ranks with a required `score` prop instead of the shell's launcher scorer. Pass `scoreBySubstring` unless you rank results yourself.
- `Slider` sets `--alpine-slider-progress` rather than the shell's `--slider-progress`, so it no longer shares a custom property with the shell's topbar sliders.
- `SCAN_BEACON_CLASS`, a class that only the library's compiled files contain. A consumer's built CSS holds `--alpine-ui-scanned` exactly when its Tailwind scanned the library.
- `@alpine/ui/index.css`, imported after `tailwindcss`. It declares `@source "../dist"`, so the consumer's Tailwind generates the classes the compiled components use, and brings three parts ported from the shell:
  - the 27 `--alpine-*` tokens derived from `--alpine-ground`, light on `:root` and dark on `data-theme="dark"`. A bare `data-theme` selector themes any subtree, and the `:root`-qualified selectors keep their specificity on `<html>`;
  - the Tailwind theme: `@theme inline` maps the tokens to utilities such as `bg-fill-solid`, `text-ink-primary` and `border-line-hairline`, next to the type, radius, spacing and easing scale (`text-dense`, `text-eyebrow`, `rounded-card`, `rounded-field`, `ease-state`) and `font-display`, which falls back to Georgia. The sans and mono stacks stay with each consumer;
  - the unlayered component rules: `.ui-slider`, filled from a registered `--alpine-slider-progress`, and `.focus-ring:focus-visible`.
- `@alpine/ui/palettes/paper.css`, the opt-in paper palette: the website's light ramp on `data-palette="paper"`, on `<html>` or on any subtree. It sets every token but `--alpine-ground`, so a paper subtree inside a dark theme keeps paper's colours. Import it after `index.css`.
- `buttonClassName({ variant, size, className })`, the classes `Button` renders, for an element that should look like a button without being one, such as a link. It carries no `'use client'`, so a React Server Component can call it. `ButtonClassNameOptions` types its argument.
- `Button` takes the native attributes of a `<button>` and a `ref`, and passes them to the element it renders, so a consumer can set `type`, `name`, `form` or `aria-haspopup`. `onClick` is optional and receives the click event. `type` still defaults to `"button"`, so a `Button` submits a form only when it is given `type="submit"`. `aria-busy` stays with the `busy` prop.
- `IconButton` takes `shape="round"` for a circle; the default, `"square"`, keeps the rounded field shape. `IconButtonShape` types it. `IconButton` also takes the native attributes of a `<button>` and a `ref`, so a menu toggle can carry `aria-expanded`, and its `onClick` receives the click event. `label` still names it, as `aria-label` and `title`.
- `EmptyState` takes `variant="dashed"` for a dashed border in the stronger line colour, the look of a box still waiting for its content. The default, `"solid"`, keeps the hairline border. `EmptyStateVariant` types it.
- `TextField` takes the input types `email`, `url`, `search` and `tel` next to `text` and `password`; `TextFieldType` types them. It also passes the native attributes of an `<input>` to its input, the form attributes included: `name`, `id`, `required`, `autoComplete`, `maxLength`, `inputMode` and `aria-describedby`, among others. `className` still lays out the wrapper, `label` still names the input, and `onChange` and `onSubmit` keep their string and Enter-key signatures.
- `Slider` reports fractional steps. It reads the value with `Number()` instead of `parseInt`, so `step={0.5}` reports 2.5 where the shell's copy reports 2. It also takes a `className` for the layout of its row.
- `Spinner` takes an optional `label`. With one it renders `role="status"` named by the label, so a spinner that stands alone is announced. Without one it stays hidden from assistive technology, as before, for a spinner that sits beside words saying the same thing.
- `Segmented` and `Select` take readonly option arrays, such as a constant declared `as const`, so a consumer no longer copies its options into a fresh array first. Mutable arrays still work.
- `.ui-slider` also styles Firefox's range parts: `::-moz-range-thumb` is hidden like the WebKit thumb, and `::-moz-range-track` and `::-moz-range-progress` are transparent, so the fill drawn from `--alpine-slider-progress` shows in Firefox as it does in Chromium. The shell's copy styles only the WebKit thumb.
